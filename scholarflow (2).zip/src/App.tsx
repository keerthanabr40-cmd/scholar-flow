import React, { useState } from 'react';
import {
  ViewType,
  StudentProfile,
  Assignment,
  Subject,
  ClassSession,
  Deadline,
  TimetableBlock,
} from './types';
import {
  initialProfile,
  initialAssignments,
  initialTodayClasses,
  initialDeadlines,
  initialSubjects,
  initialTimetableBlocks,
} from './data/mockData';

import { NavigationDrawer } from './components/NavigationDrawer';
import { TopAppBar } from './components/TopAppBar';
import { SearchModal } from './components/SearchModal';
import { NewTaskModal } from './components/NewTaskModal';
import { EnrollSubjectModal } from './components/EnrollSubjectModal';
import { NewDeadlineModal } from './components/NewDeadlineModal';

import { LoginScreen } from './components/LoginScreen';
import { RegisterScreen } from './components/RegisterScreen';
import { ForgotPasswordScreen } from './components/ForgotPasswordScreen';
import { DashboardScreen } from './components/DashboardScreen';
import { AssignmentsScreen } from './components/AssignmentsScreen';
import { AnalyticsScreen } from './components/AnalyticsScreen';
import { SubjectsScreen } from './components/SubjectsScreen';
import { TimetableScreen } from './components/TimetableScreen';
import { CalendarScreen } from './components/CalendarScreen';

export default function App() {
  const [currentView, setCurrentView] = useState<ViewType>('dashboard');
  const [profile, setProfile] = useState<StudentProfile>(initialProfile);
  const [assignments, setAssignments] = useState<Assignment[]>(initialAssignments);
  const [subjects, setSubjects] = useState<Subject[]>(initialSubjects);
  const [todayClasses] = useState<ClassSession[]>(initialTodayClasses);
  const [deadlines, setDeadlines] = useState<Deadline[]>(initialDeadlines);
  const [timetableBlocks, setTimetableBlocks] = useState<TimetableBlock[]>(initialTimetableBlocks);

  // Modal Visibility
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isNewTaskOpen, setIsNewTaskOpen] = useState(false);
  const [isEnrollSubjectOpen, setIsEnrollSubjectOpen] = useState(false);
  const [isNewDeadlineOpen, setIsNewDeadlineOpen] = useState(false);
  const [isMobileNavOpen, setIsMobileNavOpen] = useState(false);

  // Assignment handlers
  const handleAddTask = (newTask: Assignment) => {
    setAssignments((prev) => [newTask, ...prev]);
  };

  const handleUpdateTaskProgress = (id: string, newProgress: number) => {
    setAssignments((prev) =>
      prev.map((a) => {
        if (a.id === id) {
          const status =
            newProgress === 100 ? 'Done' : newProgress > 0 ? 'In Progress' : 'Pending';
          return { ...a, progress: newProgress, status };
        }
        return a;
      })
    );
  };

  const handleToggleTaskStatus = (id: string) => {
    setAssignments((prev) =>
      prev.map((a) => {
        if (a.id === id) {
          const isDone = a.status === 'Done';
          return {
            ...a,
            status: isDone ? 'Pending' : 'Done',
            progress: isDone ? 0 : 100,
          };
        }
        return a;
      })
    );
  };

  const handleDeleteTask = (id: string) => {
    setAssignments((prev) => prev.filter((a) => a.id !== id));
  };

  // Subject handlers
  const handleAddSubject = (newSubject: Subject) => {
    setSubjects((prev) => [...prev, newSubject]);
  };

  const handleDeleteSubject = (id: string) => {
    setSubjects((prev) => prev.filter((s) => s.id !== id));
  };

  const handleUpdateSubjectAttendance = (id: string, newAttendance: number) => {
    setSubjects((prev) =>
      prev.map((s) => (s.id === id ? { ...s, attendance: newAttendance } : s))
    );
  };

  // Deadline handlers
  const handleAddDeadline = (newDeadline: Deadline) => {
    setDeadlines((prev) => [newDeadline, ...prev]);
  };

  // Timetable handlers
  const handleAddTimetableBlock = (newBlock: TimetableBlock) => {
    setTimetableBlocks((prev) => [...prev, newBlock]);
  };

  const handleDeleteTimetableBlock = (id: string) => {
    setTimetableBlocks((prev) => prev.filter((b) => b.id !== id));
  };

  // Auth Success updates
  const handleLoginSuccess = (email: string) => {
    setProfile((prev) => ({
      ...prev,
      email,
      name: email.split('@')[0].replace('.', ' ') || prev.name,
    }));
  };

  const handleRegisterSuccess = (fullName: string, email: string) => {
    setProfile((prev) => ({
      ...prev,
      name: fullName,
      email,
    }));
  };

  // Render Auth Views without app Shell
  if (currentView === 'login') {
    return (
      <LoginScreen
        onNavigate={setCurrentView}
        onLoginSuccess={handleLoginSuccess}
      />
    );
  }

  if (currentView === 'register') {
    return (
      <RegisterScreen
        onNavigate={setCurrentView}
        onRegisterSuccess={handleRegisterSuccess}
      />
    );
  }

  if (currentView === 'forgot-password') {
    return <ForgotPasswordScreen onNavigate={setCurrentView} />;
  }

  const pendingTaskCount = assignments.filter((a) => a.status !== 'Done').length;

  return (
    <div className="min-h-screen bg-background text-on-surface flex flex-col font-geist antialiased selection:bg-primary-fixed selection:text-on-primary-fixed">
      {/* Navigation Drawer */}
      <NavigationDrawer
        currentView={currentView}
        onNavigate={setCurrentView}
        profile={profile}
        isOpenMobile={isMobileNavOpen}
        onCloseMobile={() => setIsMobileNavOpen(false)}
      />

      {/* Main Content Wrap offset by sidebar on desktop */}
      <div className="md:pl-sidebar-width flex-1 flex flex-col min-h-screen">
        {/* Top App Bar */}
        <TopAppBar
          profile={profile}
          onOpenMobileMenu={() => setIsMobileNavOpen(true)}
          onOpenSearch={() => setIsSearchOpen(true)}
          onNavigateProfile={() => setCurrentView('dashboard')}
        />

        {/* View Router */}
        {currentView === 'dashboard' && (
          <DashboardScreen
            profile={profile}
            todayClasses={todayClasses}
            deadlines={deadlines}
            pendingTaskCount={pendingTaskCount}
            onNavigate={setCurrentView}
            onOpenNewDeadlineModal={() => setIsNewDeadlineOpen(true)}
          />
        )}

        {currentView === 'assignments' && (
          <AssignmentsScreen
            assignments={assignments}
            onOpenNewTaskModal={() => setIsNewTaskOpen(true)}
            onUpdateProgress={handleUpdateTaskProgress}
            onToggleStatus={handleToggleTaskStatus}
            onDeleteTask={handleDeleteTask}
          />
        )}

        {currentView === 'analytics' && <AnalyticsScreen />}

        {currentView === 'subjects' && (
          <SubjectsScreen
            subjects={subjects}
            onOpenEnrollModal={() => setIsEnrollSubjectOpen(true)}
            onDeleteSubject={handleDeleteSubject}
            onUpdateAttendance={handleUpdateSubjectAttendance}
          />
        )}

        {currentView === 'timetable' && (
          <TimetableScreen
            blocks={timetableBlocks}
            onAddBlock={handleAddTimetableBlock}
            onDeleteBlock={handleDeleteTimetableBlock}
          />
        )}

        {currentView === 'calendar' && (
          <CalendarScreen
            deadlines={deadlines}
            onOpenNewDeadlineModal={() => setIsNewDeadlineOpen(true)}
          />
        )}

        {/* Footer */}
        <footer className="mt-auto py-6 px-4 md:px-margin-desktop border-t border-outline-variant/10 text-center text-label-sm text-on-surface-variant/70">
          <p>ScholarFlow • Academic Management System © 2026</p>
        </footer>
      </div>

      {/* Global Modals */}
      <SearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        assignments={assignments}
        subjects={subjects}
        todayClasses={todayClasses}
        deadlines={deadlines}
        onNavigate={setCurrentView}
      />

      <NewTaskModal
        isOpen={isNewTaskOpen}
        onClose={() => setIsNewTaskOpen(false)}
        onAddTask={handleAddTask}
      />

      <EnrollSubjectModal
        isOpen={isEnrollSubjectOpen}
        onClose={() => setIsEnrollSubjectOpen(false)}
        onAddSubject={handleAddSubject}
      />

      <NewDeadlineModal
        isOpen={isNewDeadlineOpen}
        onClose={() => setIsNewDeadlineOpen(false)}
        onAddDeadline={handleAddDeadline}
      />
    </div>
  );
}
