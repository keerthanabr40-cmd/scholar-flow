import React from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  CartesianGrid,
} from 'recharts';
import { gpaTrendData, studyHoursData } from '../data/mockData';

export const AnalyticsScreen: React.FC = () => {
  const handleExport = () => {
    alert('Academic Analytics Report exported as PDF successfully!');
  };

  return (
    <main className="flex-1 p-4 md:p-margin-desktop max-w-container-max mx-auto w-full flex flex-col gap-6 md:gap-gutter">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-surface-variant pb-6">
        <div>
          <h1 className="text-3xl md:text-headline-lg font-bold text-on-surface tracking-tight">
            Academic Analytics
          </h1>
          <p className="text-body-md text-on-surface-variant mt-1">
            Performance metrics and study habits breakdown
          </p>
        </div>
        <button
          onClick={handleExport}
          className="bg-surface-container-high text-primary hover:bg-surface-variant font-bold px-6 py-3 rounded-full flex items-center gap-2 border border-outline-variant/30 active:scale-95 transition-all cursor-pointer"
        >
          <span className="material-symbols-outlined text-[20px]">download</span>
          <span>Export Report</span>
        </button>
      </div>

      {/* Grid Row 1: GPA Trend & Grade Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-gutter">
        {/* GPA Trend Chart */}
        <div className="lg:col-span-8 bg-surface rounded-2xl p-6 card-shadow border border-surface-container-high flex flex-col">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h2 className="text-headline-md font-bold text-on-surface">GPA Progression</h2>
              <p className="text-label-sm text-on-surface-variant">Semester-by-semester trajectory</p>
            </div>
            <span className="text-label-md font-bold text-primary bg-primary-fixed/40 px-3 py-1 rounded-full">
              +0.27 Overall Growth
            </span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={gpaTrendData} margin={{ top: 10, right: 20, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0dee1" />
                <XAxis dataKey="semester" stroke="#867273" tick={{ fontSize: 12 }} />
                <YAxis domain={[3.0, 4.0]} stroke="#867273" tick={{ fontSize: 12 }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#fff8f8',
                    borderColor: '#d8c1c2',
                    borderRadius: '12px',
                    boxShadow: '0 4px 12px rgba(0,0,0,0.05)',
                  }}
                />
                <Line
                  type="monotone"
                  dataKey="gpa"
                  name="Semester GPA"
                  stroke="#561922"
                  strokeWidth={3}
                  dot={{ r: 5, fill: '#561922' }}
                  activeDot={{ r: 8, fill: '#722f37' }}
                />
                <Line
                  type="monotone"
                  dataKey="cgpa"
                  name="Cumulative CGPA"
                  stroke="#70585b"
                  strokeWidth={2}
                  strokeDasharray="4 4"
                  dot={{ r: 4, fill: '#70585b' }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Grade Distribution */}
        <div className="lg:col-span-4 bg-surface rounded-2xl p-6 card-shadow border border-surface-container-high flex flex-col justify-between">
          <div>
            <h2 className="text-headline-md font-bold text-on-surface mb-1">Grade Breakdown</h2>
            <p className="text-label-sm text-on-surface-variant mb-6">Current term performance</p>

            <div className="space-y-4">
              {/* Grade A */}
              <div>
                <div className="flex justify-between text-body-md font-bold mb-1">
                  <span className="text-on-surface">Grade A / A+</span>
                  <span className="text-primary">75% (6 Subjects)</span>
                </div>
                <div className="w-full bg-surface-variant h-3 rounded-full overflow-hidden">
                  <div className="bg-primary h-full rounded-full" style={{ width: '75%' }} />
                </div>
              </div>

              {/* Grade B */}
              <div>
                <div className="flex justify-between text-body-md font-bold mb-1">
                  <span className="text-on-surface">Grade B / B+</span>
                  <span className="text-secondary">20% (2 Subjects)</span>
                </div>
                <div className="w-full bg-surface-variant h-3 rounded-full overflow-hidden">
                  <div className="bg-secondary h-full rounded-full" style={{ width: '20%' }} />
                </div>
              </div>

              {/* Grade C */}
              <div>
                <div className="flex justify-between text-body-md font-bold mb-1">
                  <span className="text-on-surface">Grade C</span>
                  <span className="text-outline">5% (0 Subjects)</span>
                </div>
                <div className="w-full bg-surface-variant h-3 rounded-full overflow-hidden">
                  <div className="bg-outline-variant h-full rounded-full" style={{ width: '5%' }} />
                </div>
              </div>
            </div>
          </div>

          <div className="mt-6 p-4 bg-surface-container-low rounded-xl border border-surface-variant flex items-center justify-between">
            <div>
              <span className="text-label-sm text-on-surface-variant uppercase font-bold">
                Target Status
              </span>
              <p className="text-body-md font-bold text-primary">Dean's Honor List</p>
            </div>
            <span className="material-symbols-outlined text-primary text-3xl">verified</span>
          </div>
        </div>
      </div>

      {/* Grid Row 2: Study Hours & Attendance Analytics */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-gutter">
        {/* Weekly Study Hours */}
        <div className="lg:col-span-7 bg-surface rounded-2xl p-6 card-shadow border border-surface-container-high flex flex-col">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h2 className="text-headline-md font-bold text-on-surface">Weekly Study Hours</h2>
              <p className="text-label-sm text-on-surface-variant">Logged hours per day</p>
            </div>
            <span className="text-headline-sm font-bold text-primary">31.8 hrs / wk</span>
          </div>

          <div className="h-60 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={studyHoursData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0dee1" />
                <XAxis dataKey="day" stroke="#867273" tick={{ fontSize: 12 }} />
                <YAxis stroke="#867273" tick={{ fontSize: 12 }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#fff8f8',
                    borderColor: '#d8c1c2',
                    borderRadius: '12px',
                  }}
                />
                <Bar dataKey="hours" fill="#561922" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Attendance Consistency Widget */}
        <div className="lg:col-span-5 bg-surface rounded-2xl p-6 card-shadow border border-surface-container-high flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-start mb-4">
              <div>
                <h2 className="text-headline-md font-bold text-on-surface">Attendance Rate</h2>
                <p className="text-label-sm text-on-surface-variant">Semester presence logs</p>
              </div>
              <div className="w-12 h-12 rounded-full bg-secondary-container text-secondary flex items-center justify-center font-bold text-lg">
                88%
              </div>
            </div>

            <div className="space-y-3 mt-6">
              <div className="p-3 bg-surface-container-lowest rounded-xl border border-outline-variant/20 flex justify-between items-center">
                <span className="text-body-md font-medium text-on-surface">Lecture Consistency</span>
                <span className="text-label-md font-bold text-primary">95%</span>
              </div>
              <div className="p-3 bg-surface-container-lowest rounded-xl border border-outline-variant/20 flex justify-between items-center">
                <span className="text-body-md font-medium text-on-surface">Lab Attendance</span>
                <span className="text-label-md font-bold text-primary">100%</span>
              </div>
              <div className="p-3 bg-surface-container-lowest rounded-xl border border-outline-variant/20 flex justify-between items-center">
                <span className="text-body-md font-medium text-on-surface">Unexcused Absences</span>
                <span className="text-label-md font-bold text-secondary">0 Days</span>
              </div>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-outline-variant/20 flex items-center justify-between text-label-md text-on-surface-variant">
            <span>Minimum Requirement: 80%</span>
            <span className="text-primary font-bold">Target Exceeded ✓</span>
          </div>
        </div>
      </div>
    </main>
  );
};
