import React, { useState } from 'react';
import { Assignment, PriorityType } from '../types';

interface AssignmentsScreenProps {
  assignments: Assignment[];
  onOpenNewTaskModal: () => void;
  onUpdateProgress: (id: string, newProgress: number) => void;
  onToggleStatus: (id: string) => void;
  onDeleteTask: (id: string) => void;
}

export const AssignmentsScreen: React.FC<AssignmentsScreenProps> = ({
  assignments,
  onOpenNewTaskModal,
  onUpdateProgress,
  onToggleStatus,
  onDeleteTask,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [courseFilter, setCourseFilter] = useState('All');
  const [statusFilter, setStatusFilter] = useState<'All' | 'Pending' | 'In Progress' | 'Done'>('All');

  const coursesList = ['All', ...Array.from(new Set(assignments.map((a) => a.course)))];

  const filteredAssignments = assignments.filter((a) => {
    const matchesQuery =
      a.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      a.course.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCourse = courseFilter === 'All' || a.course === courseFilter;
    const matchesStatus = statusFilter === 'All' || a.status === statusFilter;
    return matchesQuery && matchesCourse && matchesStatus;
  });

  const getPriorityTasks = (priority: PriorityType) =>
    filteredAssignments.filter((a) => a.priority === priority && a.status !== 'Done');

  const completedTasks = filteredAssignments.filter((a) => a.status === 'Done');

  return (
    <main className="flex-1 p-4 md:p-margin-desktop max-w-container-max mx-auto w-full flex flex-col gap-6 md:gap-gutter">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-surface-variant pb-6">
        <div>
          <h1 className="text-3xl md:text-headline-lg font-bold text-on-surface tracking-tight">
            Assignments
          </h1>
          <p className="text-body-md text-on-surface-variant mt-1">
            Track and manage your upcoming tasks
          </p>
        </div>
        <button
          onClick={onOpenNewTaskModal}
          className="bg-primary text-on-primary hover:bg-primary/90 font-bold px-6 py-3 rounded-full flex items-center gap-2 shadow-sm active:scale-95 transition-all cursor-pointer"
        >
          <span className="material-symbols-outlined text-[20px]">add</span>
          <span>New Task</span>
        </button>
      </div>

      {/* Filters & Search */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-4 bg-surface rounded-2xl p-4 card-shadow border border-surface-container-high">
        {/* Search Input */}
        <div className="relative w-full md:w-80">
          <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-on-surface-variant text-[20px]">
            search
          </span>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search tasks..."
            className="w-full pl-10 pr-4 py-2 bg-surface-container-lowest border border-outline-variant rounded-xl text-body-md text-on-surface placeholder:text-on-surface-variant/50 focus:outline-none focus:border-primary"
          />
        </div>

        {/* Filter Selects & Status Tabs */}
        <div className="flex flex-wrap items-center gap-3 w-full md:w-auto justify-between md:justify-end">
          {/* Course Filter */}
          <select
            value={courseFilter}
            onChange={(e) => setCourseFilter(e.target.value)}
            className="px-3 py-2 bg-surface-container-lowest border border-outline-variant rounded-xl text-body-md font-medium text-on-surface focus:outline-none focus:border-primary cursor-pointer"
          >
            {coursesList.map((c) => (
              <option key={c} value={c}>
                {c === 'All' ? 'All Courses' : c}
              </option>
            ))}
          </select>

          {/* Status Tabs */}
          <div className="flex p-1 bg-surface-container-low rounded-xl border border-surface-variant text-label-sm font-bold">
            {(['All', 'Pending', 'In Progress', 'Done'] as const).map((st) => (
              <button
                key={st}
                onClick={() => setStatusFilter(st)}
                className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                  statusFilter === st
                    ? 'bg-surface text-primary shadow-2xs font-bold'
                    : 'text-on-surface-variant hover:text-on-surface'
                }`}
              >
                {st}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Priority Sections Grid */}
      <div className="space-y-8">
        {/* High Priority Section */}
        {getPriorityTasks('high').length > 0 && (
          <section className="space-y-4">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-error" />
              <h2 className="text-body-lg font-bold text-on-surface uppercase tracking-wider">
                High Priority ({getPriorityTasks('high').length})
              </h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-gutter">
              {getPriorityTasks('high').map((task) => (
                <TaskCard
                  key={task.id}
                  task={task}
                  onUpdateProgress={onUpdateProgress}
                  onToggleStatus={onToggleStatus}
                  onDeleteTask={onDeleteTask}
                />
              ))}
            </div>
          </section>
        )}

        {/* Medium Priority Section */}
        {getPriorityTasks('medium').length > 0 && (
          <section className="space-y-4">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-primary" />
              <h2 className="text-body-lg font-bold text-on-surface uppercase tracking-wider">
                Medium Priority ({getPriorityTasks('medium').length})
              </h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-gutter">
              {getPriorityTasks('medium').map((task) => (
                <TaskCard
                  key={task.id}
                  task={task}
                  onUpdateProgress={onUpdateProgress}
                  onToggleStatus={onToggleStatus}
                  onDeleteTask={onDeleteTask}
                />
              ))}
            </div>
          </section>
        )}

        {/* Low Priority Section */}
        {getPriorityTasks('low').length > 0 && (
          <section className="space-y-4">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-secondary" />
              <h2 className="text-body-lg font-bold text-on-surface uppercase tracking-wider">
                Low Priority ({getPriorityTasks('low').length})
              </h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-gutter">
              {getPriorityTasks('low').map((task) => (
                <TaskCard
                  key={task.id}
                  task={task}
                  onUpdateProgress={onUpdateProgress}
                  onToggleStatus={onToggleStatus}
                  onDeleteTask={onDeleteTask}
                />
              ))}
            </div>
          </section>
        )}

        {/* Completed Tasks Section */}
        {completedTasks.length > 0 && (
          <section className="space-y-4">
            <div className="flex items-center gap-2 pt-4 border-t border-surface-variant">
              <span className="material-symbols-outlined text-primary text-[20px]">
                check_circle
              </span>
              <h2 className="text-body-lg font-bold text-on-surface uppercase tracking-wider">
                Completed ({completedTasks.length})
              </h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-gutter">
              {completedTasks.map((task) => (
                <TaskCard
                  key={task.id}
                  task={task}
                  onUpdateProgress={onUpdateProgress}
                  onToggleStatus={onToggleStatus}
                  onDeleteTask={onDeleteTask}
                />
              ))}
            </div>
          </section>
        )}

        {filteredAssignments.length === 0 && (
          <div className="py-16 text-center bg-surface rounded-2xl border border-surface-container-high p-8">
            <span className="material-symbols-outlined text-5xl text-outline mb-2">
              task_alt
            </span>
            <h3 className="text-headline-md font-bold text-on-surface">No tasks found</h3>
            <p className="text-body-md text-on-surface-variant mt-1">
              Try resetting your search query or filters.
            </p>
          </div>
        )}
      </div>
    </main>
  );
};

interface TaskCardProps {
  task: Assignment;
  onUpdateProgress: (id: string, newProgress: number) => void;
  onToggleStatus: (id: string) => void;
  onDeleteTask: (id: string) => void;
}

const TaskCard: React.FC<TaskCardProps> = ({
  task,
  onUpdateProgress,
  onToggleStatus,
  onDeleteTask,
}) => {
  const isDone = task.status === 'Done';

  return (
    <div
      className={`bg-surface rounded-2xl p-6 card-shadow border border-surface-container-high flex flex-col gap-4 relative transition-all hover:border-primary/30 ${
        isDone ? 'opacity-70 bg-surface-container-low/50' : ''
      }`}
    >
      <div className="flex justify-between items-start gap-3">
        <div className="flex items-start gap-3 flex-1 min-w-0">
          <button
            onClick={() => onToggleStatus(task.id)}
            className={`mt-1 w-5 h-5 rounded border flex items-center justify-center transition-colors cursor-pointer shrink-0 ${
              isDone
                ? 'bg-primary border-primary text-on-primary'
                : 'border-outline-variant hover:border-primary'
            }`}
            title={isDone ? 'Mark as Incomplete' : 'Mark as Done'}
          >
            {isDone && <span className="material-symbols-outlined text-sm font-bold">check</span>}
          </button>
          <div className="min-w-0">
            <h3
              className={`text-headline-sm font-bold text-on-surface truncate ${
                isDone ? 'line-through text-on-surface-variant' : ''
              }`}
            >
              {task.title}
            </h3>
            <p className="text-body-md text-secondary font-medium mt-0.5 truncate">{task.course}</p>
          </div>
        </div>

        <button
          onClick={() => onDeleteTask(task.id)}
          className="text-on-surface-variant hover:text-error p-1 rounded-full hover:bg-surface-container-high transition-colors cursor-pointer"
          title="Delete Task"
        >
          <span className="material-symbols-outlined text-[18px]">delete</span>
        </button>
      </div>

      {/* Priority Badge & Due Date */}
      <div className="flex items-center justify-between text-label-md">
        <span
          className={`px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${
            task.priority === 'high'
              ? 'bg-error-container text-on-error-container'
              : task.priority === 'medium'
              ? 'bg-primary-fixed text-on-primary-fixed'
              : 'bg-surface-variant text-on-surface-variant'
          }`}
        >
          {task.priority} Priority
        </span>

        <div className="flex items-center gap-1.5 text-on-surface-variant">
          <span className="material-symbols-outlined text-[18px]">{task.dueIcon}</span>
          <span className="font-semibold">{task.dueDateText}</span>
        </div>
      </div>

      {/* Progress Bar & Slider */}
      <div className="pt-2">
        <div className="flex justify-between text-label-sm font-bold mb-1">
          <span className="text-on-surface-variant">Progress</span>
          <span className="text-primary">{task.progress}%</span>
        </div>
        <input
          type="range"
          min="0"
          max="100"
          step="5"
          value={task.progress}
          onChange={(e) => onUpdateProgress(task.id, Number(e.target.value))}
          className="w-full accent-primary cursor-pointer"
        />
      </div>
    </div>
  );
};
