import React, { useState } from 'react';
import { Deadline } from '../types';

interface CalendarScreenProps {
  deadlines: Deadline[];
  onOpenNewDeadlineModal: () => void;
}

export const CalendarScreen: React.FC<CalendarScreenProps> = ({
  deadlines,
  onOpenNewDeadlineModal,
}) => {
  const [currentMonth, setCurrentMonth] = useState<'OCTOBER' | 'NOVEMBER'>('OCTOBER');
  const [selectedDay, setSelectedDay] = useState<number | null>(26);

  const daysInOctober = 31;
  const startDayOctober = 2; // Starts on Tuesday

  const daysArray = Array.from({ length: daysInOctober }, (_, i) => i + 1);

  const getDeadlinesForDay = (dayNum: number) => {
    return deadlines.filter((d) => {
      if (currentMonth === 'OCTOBER' && d.month.toUpperCase() === 'OCT') {
        return Number(d.day) === dayNum;
      }
      if (currentMonth === 'NOVEMBER' && d.month.toUpperCase() === 'NOV') {
        return Number(d.day) === dayNum;
      }
      return false;
    });
  };

  const selectedDayEvents = selectedDay ? getDeadlinesForDay(selectedDay) : [];

  return (
    <main className="flex-1 p-4 md:p-margin-desktop max-w-container-max mx-auto w-full flex flex-col gap-6 md:gap-gutter">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-surface-variant pb-6">
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-3xl md:text-headline-lg font-bold text-on-surface tracking-tight">
              {currentMonth} 2026
            </h1>
            <div className="flex items-center gap-1 bg-surface-container-low rounded-full p-1 border border-outline-variant/30">
              <button
                onClick={() => setCurrentMonth('OCTOBER')}
                className={`p-1.5 rounded-full hover:bg-surface-variant transition-colors cursor-pointer ${
                  currentMonth === 'OCTOBER' ? 'bg-primary text-on-primary font-bold' : ''
                }`}
                title="Previous Month"
              >
                <span className="material-symbols-outlined text-[18px]">chevron_left</span>
              </button>
              <button
                onClick={() => setCurrentMonth('NOVEMBER')}
                className={`p-1.5 rounded-full hover:bg-surface-variant transition-colors cursor-pointer ${
                  currentMonth === 'NOVEMBER' ? 'bg-primary text-on-primary font-bold' : ''
                }`}
                title="Next Month"
              >
                <span className="material-symbols-outlined text-[18px]">chevron_right</span>
              </button>
            </div>
          </div>
          <p className="text-body-md text-on-surface-variant mt-1">
            Academic milestones, exams, and project submission deadlines
          </p>
        </div>

        <button
          onClick={onOpenNewDeadlineModal}
          className="bg-primary text-on-primary hover:bg-primary/90 font-bold px-6 py-3 rounded-full flex items-center gap-2 shadow-sm active:scale-95 transition-all cursor-pointer"
        >
          <span className="material-symbols-outlined text-[20px]">add</span>
          <span>Add Deadline</span>
        </button>
      </div>

      {/* Grid Layout: Calendar Grid + Day Details Side Pane */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-gutter">
        {/* Main Calendar Month Grid */}
        <div className="lg:col-span-8 bg-surface rounded-2xl p-6 card-shadow border border-surface-container-high flex flex-col">
          {/* Weekday Labels */}
          <div className="grid grid-cols-7 text-center font-bold text-label-md text-on-surface-variant mb-4 pb-2 border-b border-surface-variant">
            <span>SUN</span>
            <span>MON</span>
            <span>TUE</span>
            <span>WED</span>
            <span>THU</span>
            <span>FRI</span>
            <span>SAT</span>
          </div>

          {/* Day Cells Grid */}
          <div className="grid grid-cols-7 gap-2">
            {/* Blank offset cells for starting weekday */}
            {Array.from({ length: startDayOctober }).map((_, i) => (
              <div key={`offset-${i}`} className="h-20 md:h-24 p-2 rounded-xl bg-transparent" />
            ))}

            {daysArray.map((dayNum) => {
              const dayDeadlines = getDeadlinesForDay(dayNum);
              const isSelected = selectedDay === dayNum;
              const hasEvents = dayDeadlines.length > 0;

              return (
                <div
                  key={dayNum}
                  onClick={() => setSelectedDay(dayNum)}
                  className={`h-20 md:h-24 p-2 rounded-xl border transition-all cursor-pointer flex flex-col justify-between ${
                    isSelected
                      ? 'bg-primary-fixed/40 border-primary ring-2 ring-primary/30'
                      : hasEvents
                      ? 'bg-surface-container-low border-primary/30 hover:border-primary'
                      : 'bg-surface-container-lowest border-outline-variant/20 hover:bg-surface-container-low'
                  }`}
                >
                  <div className="flex justify-between items-center">
                    <span
                      className={`text-label-md font-bold ${
                        isSelected
                          ? 'text-primary'
                          : hasEvents
                          ? 'text-primary font-bold'
                          : 'text-on-surface'
                      }`}
                    >
                      {dayNum}
                    </span>
                    {hasEvents && (
                      <span className="w-2 h-2 rounded-full bg-error animate-ping" />
                    )}
                  </div>

                  {/* Badges for events on this date */}
                  <div className="space-y-1 overflow-hidden">
                    {dayDeadlines.map((dl) => (
                      <div
                        key={dl.id}
                        className={`text-[10px] font-bold px-1.5 py-0.5 rounded truncate ${
                          dl.type === 'urgent'
                            ? 'bg-error-container text-on-error-container'
                            : 'bg-primary-container text-on-primary-container'
                        }`}
                      >
                        {dl.title}
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Side Details Pane */}
        <div className="lg:col-span-4 bg-surface rounded-2xl p-6 card-shadow border border-surface-container-high flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-center border-b border-surface-variant pb-4 mb-6">
              <h2 className="text-headline-md font-bold text-on-surface">
                {currentMonth.substring(0, 3)} {selectedDay || 'Selected'} Agenda
              </h2>
              <span className="text-label-sm font-bold bg-surface-variant text-on-surface-variant px-3 py-1 rounded-full">
                {selectedDayEvents.length} Events
              </span>
            </div>

            {selectedDayEvents.length > 0 ? (
              <div className="space-y-4">
                {selectedDayEvents.map((dl) => (
                  <div
                    key={dl.id}
                    className="p-4 bg-surface-container-low rounded-xl border border-surface-variant flex flex-col gap-2"
                  >
                    <div className="flex justify-between items-start">
                      <h4 className="text-headline-sm font-bold text-on-surface">{dl.title}</h4>
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase ${
                          dl.type === 'urgent'
                            ? 'bg-error-container text-on-error-container'
                            : 'bg-primary-fixed text-on-primary-fixed'
                        }`}
                      >
                        {dl.type}
                      </span>
                    </div>
                    <p className="text-body-md text-on-surface-variant">{dl.subtitle}</p>
                    <div className="flex items-center gap-1 text-label-sm font-bold text-primary mt-1">
                      <span className="material-symbols-outlined text-[16px]">schedule</span>
                      <span>11:59 PM Submission Cutoff</span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="py-12 text-center text-on-surface-variant">
                <span className="material-symbols-outlined text-4xl text-outline mb-2">
                  event_note
                </span>
                <p className="text-body-md font-medium">No deadlines for this date</p>
                <p className="text-label-sm text-outline mt-1">
                  Click on dates with red indicators to view details.
                </p>
              </div>
            )}
          </div>

          <div className="mt-8 pt-4 border-t border-surface-variant">
            <button
              onClick={onOpenNewDeadlineModal}
              className="w-full py-3 bg-primary text-on-primary rounded-full text-label-md font-bold hover:bg-primary/90 transition-colors shadow-sm cursor-pointer"
            >
              Add New Milestone
            </button>
          </div>
        </div>
      </div>
    </main>
  );
};
