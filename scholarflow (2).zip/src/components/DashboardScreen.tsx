import React from 'react';
import { StudentProfile, ClassSession, Deadline, ViewType } from '../types';

interface DashboardScreenProps {
  profile: StudentProfile;
  todayClasses: ClassSession[];
  deadlines: Deadline[];
  pendingTaskCount: number;
  onNavigate: (view: ViewType) => void;
  onOpenNewDeadlineModal: () => void;
}

export const DashboardScreen: React.FC<DashboardScreenProps> = ({
  profile,
  todayClasses,
  deadlines,
  pendingTaskCount,
  onNavigate,
  onOpenNewDeadlineModal,
}) => {
  const firstName = profile.name.split(' ')[0] || 'Alex';

  return (
    <main className="flex-1 p-4 md:p-margin-desktop max-w-container-max mx-auto w-full flex flex-col gap-8 md:gap-section-gap">
      {/* Welcome Header */}
      <section className="flex flex-col gap-2">
        <h1 className="text-3xl md:text-display-lg font-bold text-on-surface tracking-tight">
          Welcome back, {firstName}.
        </h1>
        <p className="text-body-lg text-on-surface-variant">
          Here is an overview of your academic progress today.
        </p>
      </section>

      {/* Grid Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-gutter">
        {/* Left Column (Main Stats & Timeline) */}
        <div className="lg:col-span-8 flex flex-col gap-gutter">
          {/* Metrics Bento */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-gutter">
            {/* Attendance Card */}
            <div className="bg-surface rounded-2xl p-6 card-shadow border border-surface-container-high flex flex-col gap-4 hover:border-primary/20 transition-all">
              <div className="flex justify-between items-start">
                <span className="p-3 bg-secondary-container rounded-xl text-secondary flex items-center justify-center">
                  <span className="material-symbols-outlined">how_to_reg</span>
                </span>
                <span className="text-label-sm bg-surface-variant text-on-surface-variant px-3 py-1 rounded-full font-bold">
                  Overall
                </span>
              </div>
              <div>
                <h3 className="text-label-md font-medium text-on-surface-variant mb-1">
                  Attendance
                </h3>
                <div className="flex items-end gap-2">
                  <span className="text-4xl md:text-display-lg font-bold text-primary leading-none">
                    88%
                  </span>
                  <span className="text-body-md text-secondary mb-1">Target: 85%</span>
                </div>
              </div>
              <div className="w-full bg-surface-variant rounded-full h-2 mt-2">
                <div className="bg-primary h-2 rounded-full" style={{ width: '88%' }} />
              </div>
            </div>

            {/* Pending Tasks Card */}
            <div className="bg-surface rounded-2xl p-6 card-shadow border border-surface-container-high flex flex-col gap-4 hover:border-primary/20 transition-all">
              <div className="flex justify-between items-start">
                <span className="p-3 bg-error-container rounded-xl text-error flex items-center justify-center">
                  <span className="material-symbols-outlined">assignment_late</span>
                </span>
                <span className="text-label-sm bg-error-container text-on-error-container px-3 py-1 rounded-full font-bold">
                  Action Needed
                </span>
              </div>
              <div>
                <h3 className="text-label-md font-medium text-on-surface-variant mb-1">
                  Pending Tasks
                </h3>
                <div className="flex items-end gap-2">
                  <span className="text-4xl md:text-display-lg font-bold text-on-surface leading-none">
                    {pendingTaskCount}
                  </span>
                  <span className="text-body-md text-on-surface-variant mb-1">Due this week</span>
                </div>
              </div>
              <button
                onClick={() => onNavigate('assignments')}
                className="mt-auto w-full py-2 border border-primary text-primary rounded-full text-label-md font-bold hover:bg-primary-fixed/30 transition-colors cursor-pointer"
              >
                View All
              </button>
            </div>

            {/* Current GPA Card */}
            <div className="bg-surface rounded-2xl p-6 card-shadow border border-surface-container-high flex flex-col gap-4 hover:border-primary/20 transition-all">
              <div className="flex justify-between items-start">
                <span className="p-3 bg-secondary-container rounded-xl text-secondary flex items-center justify-center">
                  <span className="material-symbols-outlined">school</span>
                </span>
                <span className="text-label-sm bg-surface-variant text-on-surface-variant px-3 py-1 rounded-full font-bold">
                  Current
                </span>
              </div>
              <div>
                <h3 className="text-label-md font-medium text-on-surface-variant mb-1">
                  Current GPA
                </h3>
                <div className="flex items-end gap-2">
                  <span className="text-4xl md:text-display-lg font-bold text-primary leading-none">
                    3.85
                  </span>
                  <span className="text-body-md text-secondary mb-1">/ 4.0</span>
                </div>
              </div>
              <div className="w-full bg-surface-variant rounded-full h-2 mt-2">
                <div className="bg-primary h-2 rounded-full" style={{ width: '96%' }} />
              </div>
            </div>

            {/* Total CGPA Card */}
            <div className="bg-surface rounded-2xl p-6 card-shadow border border-surface-container-high flex flex-col gap-4 hover:border-primary/20 transition-all">
              <div className="flex justify-between items-start">
                <span className="p-3 bg-secondary-container rounded-xl text-secondary flex items-center justify-center">
                  <span className="material-symbols-outlined">grade</span>
                </span>
                <span className="text-label-sm bg-surface-variant text-on-surface-variant px-3 py-1 rounded-full font-bold">
                  Cumulative
                </span>
              </div>
              <div>
                <h3 className="text-label-md font-medium text-on-surface-variant mb-1">
                  Total CGPA
                </h3>
                <div className="flex items-end gap-2">
                  <span className="text-4xl md:text-display-lg font-bold text-primary leading-none">
                    3.92
                  </span>
                  <span className="text-body-md text-secondary mb-1">Top 5%</span>
                </div>
              </div>
              <div className="w-full bg-surface-variant rounded-full h-2 mt-2">
                <div className="bg-primary h-2 rounded-full" style={{ width: '98%' }} />
              </div>
            </div>
          </div>

          {/* Today's Classes */}
          <div className="bg-surface rounded-2xl p-6 card-shadow border border-surface-container-high flex flex-col gap-6">
            <div className="flex justify-between items-center border-b border-secondary/20 pb-4">
              <h2 className="text-headline-md font-bold text-on-surface">Today's Classes</h2>
              <span className="text-label-md font-bold text-primary">Wed, Oct 25</span>
            </div>
            <div className="flex flex-col gap-0 relative">
              {/* Timeline Line */}
              <div className="absolute left-[39px] top-4 bottom-4 w-px bg-surface-variant" />

              {todayClasses.map((cls, idx) => (
                <div key={cls.id} className="flex items-start gap-6 py-4 relative z-10">
                  <div className="w-20 flex flex-col items-end pt-1 shrink-0">
                    <span className="text-label-md font-bold text-on-surface">
                      {cls.timeStart}
                    </span>
                    <span className="text-label-sm text-on-surface-variant">{cls.timeEnd}</span>
                  </div>
                  <div
                    className={`w-3 h-3 rounded-full mt-2 shrink-0 ring-4 ring-surface relative -left-[7px] ${
                      idx === 0 ? 'bg-primary' : 'bg-surface-variant'
                    }`}
                  />
                  <div
                    className={`flex-1 rounded-xl p-4 border border-surface-variant transition-all ${
                      idx === 0
                        ? 'bg-surface-container-low shadow-2xs'
                        : 'bg-surface-container-lowest opacity-80'
                    }`}
                  >
                    <h4 className="text-body-lg font-semibold text-on-surface">{cls.title}</h4>
                    <div className="flex flex-wrap items-center gap-4 mt-2 text-on-surface-variant">
                      <span className="flex items-center gap-1 text-label-sm">
                        <span className="material-symbols-outlined text-[16px]">location_on</span>
                        {cls.location}
                      </span>
                      <span className="flex items-center gap-1 text-label-sm">
                        <span className="material-symbols-outlined text-[16px]">person</span>
                        {cls.instructor}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column (Deadlines) */}
        <div className="lg:col-span-4 flex flex-col gap-gutter">
          <div className="bg-surface rounded-2xl p-6 card-shadow border border-surface-container-high flex flex-col h-full">
            <div className="flex justify-between items-center border-b border-secondary/20 pb-4 mb-6">
              <h2 className="text-headline-md font-bold text-on-surface">Deadlines</h2>
              <button
                onClick={onOpenNewDeadlineModal}
                className="p-2 text-primary hover:bg-primary-fixed/30 rounded-full transition-colors cursor-pointer"
                title="Add Deadline"
              >
                <span className="material-symbols-outlined">add</span>
              </button>
            </div>

            <div className="flex flex-col gap-4">
              {deadlines.map((item) => (
                <div
                  key={item.id}
                  onClick={() => onNavigate('calendar')}
                  className="flex gap-4 items-start p-3 hover:bg-surface-container-low rounded-xl transition-colors cursor-pointer border border-transparent hover:border-surface-variant"
                >
                  <div
                    className={`p-2 rounded-lg flex flex-col items-center justify-center min-w-[50px] ${
                      item.type === 'urgent'
                        ? 'bg-error-container text-on-error-container'
                        : item.type === 'normal'
                        ? 'bg-secondary-container text-secondary'
                        : 'bg-surface-variant text-on-surface-variant'
                    }`}
                  >
                    <span className="text-label-sm font-bold uppercase">{item.month}</span>
                    <span className="text-headline-md font-bold leading-none">{item.day}</span>
                  </div>
                  <div className="flex-1">
                    <h4 className="text-body-md font-semibold text-on-surface">{item.title}</h4>
                    <p className="text-label-sm text-on-surface-variant mt-1">{item.subtitle}</p>
                  </div>
                </div>
              ))}
            </div>

            <button
              onClick={() => onNavigate('calendar')}
              className="mt-8 md:mt-auto w-full py-3 bg-primary text-on-primary rounded-full text-label-md font-bold hover:bg-primary/90 transition-colors shadow-sm cursor-pointer"
            >
              View Calendar
            </button>
          </div>
        </div>
      </div>
    </main>
  );
};
