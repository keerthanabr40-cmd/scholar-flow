import React, { useState } from 'react';
import { Subject } from '../types';

interface EnrollSubjectModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddSubject: (subject: Subject) => void;
}

export const EnrollSubjectModal: React.FC<EnrollSubjectModalProps> = ({
  isOpen,
  onClose,
  onAddSubject,
}) => {
  const [code, setCode] = useState('');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [professor, setProfessor] = useState('');
  const [room, setRoom] = useState('');
  const [schedule, setSchedule] = useState('');
  const [credits, setCredits] = useState(3);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!code.trim() || !title.trim()) return;

    const newSubj: Subject = {
      id: 'subj-' + Date.now(),
      code: code.trim().toUpperCase(),
      title: title.trim(),
      description: description.trim() || 'Comprehensive course study and practical sessions.',
      professor: professor.trim() || 'Faculty Instructor',
      room: room.trim() || 'Main Building',
      schedule: schedule.trim() || 'Mon/Wed 11:00',
      credits: Number(credits) || 3,
      attendance: 100,
    };

    onAddSubject(newSubj);
    setCode('');
    setTitle('');
    setDescription('');
    setProfessor('');
    setRoom('');
    setSchedule('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs animate-in fade-in">
      <div className="fixed inset-0" onClick={onClose} />
      <div className="relative w-full max-w-lg bg-surface rounded-2xl custom-shadow border border-outline-variant/30 overflow-hidden z-10 p-6 md:p-8">
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary-container text-on-primary-container flex items-center justify-center">
              <span className="material-symbols-outlined text-2xl">school</span>
            </div>
            <div>
              <h2 className="text-headline-md font-bold text-on-surface">Enroll Subject</h2>
              <p className="text-label-sm text-on-surface-variant">
                Add new course to current semester
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-on-surface-variant hover:bg-surface-container-high transition-colors"
          >
            <span className="material-symbols-outlined">close</span>
          </button>
        </div>

        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <div className="grid grid-cols-3 gap-3">
            <div className="col-span-1">
              <label className="block text-label-md font-medium text-on-surface mb-1">Code *</label>
              <input
                type="text"
                required
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder="e.g. CS 420"
                className="w-full h-11 px-3 bg-surface-container-lowest border border-outline-variant rounded-xl text-body-md text-on-surface focus:outline-none focus:border-primary"
              />
            </div>
            <div className="col-span-2">
              <label className="block text-label-md font-medium text-on-surface mb-1">
                Course Title *
              </label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Artificial Intelligence"
                className="w-full h-11 px-4 bg-surface-container-lowest border border-outline-variant rounded-xl text-body-md text-on-surface focus:outline-none focus:border-primary"
              />
            </div>
          </div>

          <div>
            <label className="block text-label-md font-medium text-on-surface mb-1">
              Description
            </label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Brief overview of course topics..."
              className="w-full p-3 bg-surface-container-lowest border border-outline-variant rounded-xl text-body-md text-on-surface focus:outline-none focus:border-primary resize-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-label-md font-medium text-on-surface mb-1">
                Professor
              </label>
              <input
                type="text"
                value={professor}
                onChange={(e) => setProfessor(e.target.value)}
                placeholder="e.g. Dr. H. Minsky"
                className="w-full h-11 px-3 bg-surface-container-lowest border border-outline-variant rounded-xl text-body-md text-on-surface focus:outline-none focus:border-primary"
              />
            </div>
            <div>
              <label className="block text-label-md font-medium text-on-surface mb-1">
                Room / Hall
              </label>
              <input
                type="text"
                value={room}
                onChange={(e) => setRoom(e.target.value)}
                placeholder="e.g. Room 402"
                className="w-full h-11 px-3 bg-surface-container-lowest border border-outline-variant rounded-xl text-body-md text-on-surface focus:outline-none focus:border-primary"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-label-md font-medium text-on-surface mb-1">
                Schedule
              </label>
              <input
                type="text"
                value={schedule}
                onChange={(e) => setSchedule(e.target.value)}
                placeholder="e.g. Mon/Wed 10:00"
                className="w-full h-11 px-3 bg-surface-container-lowest border border-outline-variant rounded-xl text-body-md text-on-surface focus:outline-none focus:border-primary"
              />
            </div>
            <div>
              <label className="block text-label-md font-medium text-on-surface mb-1">
                Credits
              </label>
              <input
                type="number"
                min="1"
                max="6"
                value={credits}
                onChange={(e) => setCredits(Number(e.target.value))}
                className="w-full h-11 px-3 bg-surface-container-lowest border border-outline-variant rounded-xl text-body-md text-on-surface focus:outline-none focus:border-primary"
              />
            </div>
          </div>

          <div className="flex gap-3 mt-4 pt-4 border-t border-outline-variant/20">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 h-11 border border-outline-variant rounded-full text-label-md font-medium text-on-surface hover:bg-surface-container-low transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 h-11 bg-primary text-on-primary rounded-full text-label-md font-medium hover:bg-primary/90 transition-colors shadow-sm flex items-center justify-center gap-2"
            >
              <span className="material-symbols-outlined text-[18px]">add</span>
              <span>Enroll Subject</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
