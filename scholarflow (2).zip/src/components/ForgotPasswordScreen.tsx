import React, { useState } from 'react';
import { ViewType } from '../types';

interface ForgotPasswordScreenProps {
  onNavigate: (view: ViewType) => void;
}

export const ForgotPasswordScreen: React.FC<ForgotPasswordScreenProps> = ({ onNavigate }) => {
  const [email, setEmail] = useState('');
  const [isSent, setIsSent] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setIsSent(true);
    }
  };

  return (
    <div className="bg-background text-on-background min-h-screen flex items-center justify-center font-body-md antialiased p-margin-mobile md:p-margin-desktop relative overflow-hidden">
      {/* Background Blobs */}
      <div className="absolute inset-0 pointer-events-none z-0 overflow-hidden">
        <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-primary-fixed/20 rounded-full blur-[120px]" />
        <div className="absolute bottom-[-20%] right-[-10%] w-[60%] h-[60%] bg-secondary-fixed/30 rounded-full blur-[150px]" />
      </div>

      <main className="w-full max-w-[480px] bg-surface rounded-2xl shadow-[0px_8px_32px_rgba(114,47,55,0.08)] z-10 overflow-hidden border border-outline-variant/30 flex flex-col">
        {/* Header Area */}
        <div className="pt-10 pb-6 px-8 flex flex-col items-center text-center border-b border-secondary/10 bg-surface/50 backdrop-blur-xs">
          <div className="w-16 h-16 rounded-full bg-primary-container/20 flex items-center justify-center mb-6 shadow-inner">
            <span className="material-symbols-outlined text-primary text-[32px]">lock_reset</span>
          </div>
          <h1 className="font-bold text-headline-lg text-on-surface mb-2">Reset Password</h1>
          <p className="text-body-md text-on-surface-variant max-w-[320px]">
            Enter your email address below and we'll send you a link to reset your password.
          </p>
        </div>

        {/* Form Area */}
        <div className="p-8 bg-surface">
          {isSent ? (
            <div className="flex flex-col items-center text-center gap-4 py-4">
              <div className="w-12 h-12 rounded-full bg-secondary-container text-primary flex items-center justify-center">
                <span className="material-symbols-outlined text-2xl">mark_email_read</span>
              </div>
              <h3 className="text-headline-md font-bold text-on-surface">Check your inbox</h3>
              <p className="text-body-md text-on-surface-variant">
                We've sent password reset instructions to{' '}
                <strong className="text-primary">{email}</strong>.
              </p>
              <button
                onClick={() => onNavigate('login')}
                className="w-full h-12 mt-4 bg-primary text-on-primary font-bold text-label-md rounded-full shadow-sm hover:bg-primary/90 transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                Return to Login
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="flex flex-col gap-6">
              <div className="flex flex-col gap-2">
                <label className="text-label-md font-medium text-on-surface" htmlFor="email">
                  Email Address
                </label>
                <div className="relative group">
                  <span className="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-on-surface-variant group-focus-within:text-primary transition-colors">
                    mail
                  </span>
                  <input
                    id="email"
                    name="email"
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="student@university.edu"
                    className="w-full h-12 pl-12 pr-4 bg-surface-container-low border border-outline-variant rounded-xl text-body-md text-on-surface placeholder:text-on-surface-variant/50 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all shadow-xs"
                  />
                </div>
              </div>

              <div className="pt-2 flex flex-col gap-4">
                <button
                  type="submit"
                  className="w-full h-12 bg-primary text-on-primary font-bold text-label-md rounded-full shadow-[0px_4px_12px_rgba(86,25,34,0.2)] hover:shadow-[0px_6px_16px_rgba(86,25,34,0.3)] hover:-translate-y-0.5 active:translate-y-0 active:shadow-none transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <span>Send Reset Link</span>
                  <span className="material-symbols-outlined text-[18px]">arrow_forward</span>
                </button>

                <button
                  type="button"
                  onClick={() => onNavigate('login')}
                  className="w-full h-12 flex items-center justify-center text-primary font-bold text-label-md hover:bg-primary/5 rounded-full transition-colors border border-transparent hover:border-primary/20 cursor-pointer"
                >
                  Back to Login
                </button>
              </div>
            </form>
          )}
        </div>
      </main>

      <div className="absolute bottom-8 left-0 w-full text-center z-0">
        <p className="text-label-sm text-on-surface-variant/60">ScholarFlow © 2026</p>
      </div>
    </div>
  );
};
