import React, { useState } from 'react';
import { ViewType } from '../types';

interface LoginScreenProps {
  onNavigate: (view: ViewType) => void;
  onLoginSuccess: (email: string) => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({ onNavigate, onLoginSuccess }) => {
  const [email, setEmail] = useState('student@university.edu');
  const [password, setPassword] = useState('password123');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email && password) {
      onLoginSuccess(email);
      onNavigate('dashboard');
    }
  };

  return (
    <div className="bg-background min-h-screen flex flex-col justify-center items-center p-4 relative overflow-hidden font-body-md text-on-surface">
      {/* Abstract Background Elements */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden -z-10 pointer-events-none">
        <div className="absolute -top-[20%] -right-[10%] w-[60vw] h-[60vw] rounded-full bg-surface-container-high opacity-50 blur-3xl mix-blend-multiply" />
        <div className="absolute -bottom-[20%] -left-[10%] w-[50vw] h-[50vw] rounded-full bg-secondary-container opacity-40 blur-3xl mix-blend-multiply" />
      </div>

      {/* Login Container */}
      <div className="w-full max-w-md mx-auto">
        {/* Logo Area */}
        <div className="text-center mb-8">
          <h1 className="text-4xl md:text-5xl font-bold text-primary tracking-tight">
            ScholarFlow
          </h1>
          <p className="text-body-md text-on-surface-variant mt-2">
            Elevate your academic journey.
          </p>
        </div>

        {/* Login Card */}
        <div className="glass-effect custom-shadow rounded-[24px] p-8 md:p-10 border border-surface-variant">
          <h2 className="text-headline-md font-bold text-on-surface mb-6">Welcome Back</h2>

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Email Field */}
            <div>
              <label className="block text-label-md font-medium text-on-surface-variant mb-2" htmlFor="email">
                Email Address
              </label>
              <div className="relative rounded-xl border border-outline-variant bg-surface-container-lowest overflow-hidden transition-all duration-200 input-focus-ring">
                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                  <span className="material-symbols-outlined text-on-surface-variant">
                    mail
                  </span>
                </div>
                <input
                  id="email"
                  name="email"
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="student@university.edu"
                  className="block w-full pl-12 pr-4 py-3 bg-transparent border-none focus:ring-0 text-body-md text-on-surface placeholder:text-on-surface-variant/50 outline-none"
                />
              </div>
            </div>

            {/* Password Field */}
            <div>
              <div className="flex justify-between items-center mb-2">
                <label className="block text-label-md font-medium text-on-surface-variant" htmlFor="password">
                  Password
                </label>
                <button
                  type="button"
                  onClick={() => onNavigate('forgot-password')}
                  className="text-label-sm text-primary hover:text-surface-tint font-semibold transition-colors"
                >
                  Forgot Password?
                </button>
              </div>
              <div className="relative rounded-xl border border-outline-variant bg-surface-container-lowest overflow-hidden transition-all duration-200 input-focus-ring">
                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                  <span className="material-symbols-outlined text-on-surface-variant">
                    lock
                  </span>
                </div>
                <input
                  id="password"
                  name="password"
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="block w-full pl-12 pr-12 py-3 bg-transparent border-none focus:ring-0 text-body-md text-on-surface placeholder:text-on-surface-variant/50 outline-none"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute inset-y-0 right-0 pr-4 flex items-center text-on-surface-variant hover:text-primary transition-colors focus:outline-none"
                >
                  <span className="material-symbols-outlined">
                    {showPassword ? 'visibility_off' : 'visibility'}
                  </span>
                </button>
              </div>
            </div>

            {/* Remember Me */}
            <div className="flex items-center">
              <input
                id="remember-me"
                name="remember-me"
                type="checkbox"
                checked={rememberMe}
                onChange={(e) => setRememberMe(e.target.checked)}
                className="h-4 w-4 rounded border-outline-variant text-primary focus:ring-primary focus:ring-offset-background bg-surface-container-lowest cursor-pointer accent-primary"
              />
              <label htmlFor="remember-me" className="ml-2 block text-body-md text-on-surface-variant cursor-pointer">
                Remember me for 30 days
              </label>
            </div>

            {/* Submit Button */}
            <div>
              <button
                type="submit"
                className="w-full flex justify-center py-3 px-4 border border-transparent rounded-full shadow-sm text-label-md font-bold text-on-primary bg-primary hover:bg-surface-tint focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary transition-all duration-200 transform active:scale-[0.98] cursor-pointer"
              >
                Sign In
              </button>
            </div>
          </form>

          {/* Divider */}
          <div className="mt-8 relative">
            <div className="absolute inset-0 flex items-center" aria-hidden="true">
              <div className="w-full border-t border-surface-variant" />
            </div>
            <div className="relative flex justify-center">
              <span className="px-3 bg-surface-container-lowest text-label-sm text-on-surface-variant rounded-full glass-effect">
                Or continue with
              </span>
            </div>
          </div>

          {/* SSO Options */}
          <div className="mt-6 grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => {
                onLoginSuccess('student@university.edu');
                onNavigate('dashboard');
              }}
              className="w-full flex items-center justify-center gap-2 px-4 py-2.5 border border-outline-variant rounded-full shadow-xs bg-surface-container-lowest text-label-md font-medium text-on-surface hover:bg-surface-container-low transition-colors duration-200 cursor-pointer"
            >
              <svg className="h-5 w-5" viewBox="0 0 24 24">
                <path
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  fill="#4285F4"
                />
                <path
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  fill="#34A853"
                />
                <path
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                  fill="#FBBC05"
                />
                <path
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                  fill="#EA4335"
                />
              </svg>
              <span>Google</span>
            </button>

            <button
              type="button"
              onClick={() => {
                onLoginSuccess('student@university.edu');
                onNavigate('dashboard');
              }}
              className="w-full flex items-center justify-center gap-2 px-4 py-2.5 border border-outline-variant rounded-full shadow-xs bg-surface-container-lowest text-label-md font-medium text-on-surface hover:bg-surface-container-low transition-colors duration-200 cursor-pointer"
            >
              <svg className="h-5 w-5 text-on-surface" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 2C6.477 2 2 6.477 2 12c0 4.42 2.865 8.166 6.839 9.489.5.092.682-.217.682-.482 0-.237-.008-.866-.013-1.7-2.782.603-3.369-1.34-3.369-1.34-.454-1.156-1.11-1.462-1.11-1.462-.908-.62.069-.608.069-.608 1.003.07 1.531 1.03 1.531 1.03.892 1.529 2.341 1.087 2.91.831.092-.646.35-1.086.636-1.336-2.22-.253-4.555-1.11-4.555-4.943 0-1.091.39-1.984 1.029-2.683-.103-.253-.446-1.27.098-2.647 0 0 .84-.269 2.75 1.025A9.578 9.578 0 0112 6.836c.85.004 1.705.114 2.504.336 1.909-1.294 2.747-1.025 2.747-1.025.546 1.379.203 2.394.1 2.647.64.699 1.028 1.592 1.028 2.683 0 3.842-2.339 4.687-4.566 4.935.359.309.678.919.678 1.852 0 1.336-.012 2.415-.012 2.743 0 .267.18.578.688.48C19.138 20.161 22 16.418 22 12c0-5.523-4.477-10-10-10z" />
              </svg>
              <span>GitHub</span>
            </button>
          </div>
        </div>

        {/* Footer Links */}
        <p className="mt-8 text-center text-body-md text-on-surface-variant">
          Don't have an account?{' '}
          <button
            onClick={() => onNavigate('register')}
            className="text-label-md text-primary hover:text-surface-tint font-bold transition-colors underline cursor-pointer"
          >
            Create Account
          </button>
        </p>
      </div>
    </div>
  );
};
