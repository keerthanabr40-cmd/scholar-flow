import React from 'react';
import { ViewType, StudentProfile } from '../types';

interface NavigationDrawerProps {
  currentView: ViewType;
  onNavigate: (view: ViewType) => void;
  profile: StudentProfile;
  isOpenMobile?: boolean;
  onCloseMobile?: () => void;
}

export const NavigationDrawer: React.FC<NavigationDrawerProps> = ({
  currentView,
  onNavigate,
  profile,
  isOpenMobile,
  onCloseMobile,
}) => {
  const navItems: { id: ViewType; label: string; icon: string }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: 'dashboard' },
    { id: 'timetable', label: 'Timetable', icon: 'calendar_view_week' },
    { id: 'assignments', label: 'Assignments', icon: 'assignment' },
    { id: 'analytics', label: 'Analytics', icon: 'insights' },
    { id: 'subjects', label: 'Subjects', icon: 'library_books' },
    { id: 'calendar', label: 'Calendar', icon: 'calendar_today' },
  ];

  const handleNavClick = (view: ViewType) => {
    onNavigate(view);
    if (onCloseMobile) {
      onCloseMobile();
    }
  };

  const navContent = (
    <div className="flex flex-col h-full py-6">
      {/* Student Profile Header */}
      <div className="px-6 mb-8 flex items-center gap-3">
        <div className="w-12 h-12 rounded-full overflow-hidden shrink-0 border border-outline-variant/30 shadow-sm bg-surface-container-high">
          <img
            src={profile.avatarUrl}
            alt={profile.name}
            className="w-full h-full object-cover"
            onError={(e) => {
              // fallback image if remote URL blocked
              (e.currentTarget as HTMLImageElement).src =
                'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=400&auto=format&fit=crop';
            }}
          />
        </div>
        <div className="overflow-hidden">
          <h2 className="text-body-md font-bold text-on-surface truncate">{profile.name}</h2>
          <p className="text-label-sm text-on-surface-variant truncate">{profile.role}</p>
          <span className="text-[10px] font-bold text-primary tracking-wide uppercase mt-0.5 block truncate">
            {profile.tier}
          </span>
        </div>
      </div>

      {/* Main Navigation Links */}
      <nav className="flex flex-col gap-1 flex-1">
        {navItems.map((item) => {
          const isActive = currentView === item.id;
          return (
            <button
              key={item.id}
              onClick={() => handleNavClick(item.id)}
              className={`flex items-center gap-4 py-3 px-6 text-left transition-all duration-200 w-full ${
                isActive
                  ? 'text-primary font-bold border-l-4 border-primary bg-primary-fixed/30'
                  : 'text-on-surface-variant hover:bg-surface-container-high'
              }`}
            >
              <span
                className={`material-symbols-outlined text-[22px] ${isActive ? 'fill-1' : ''}`}
              >
                {item.icon}
              </span>
              <span className="text-label-md font-medium">{item.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Auth & System Links Footer */}
      <div className="px-6 pt-4 mt-auto border-t border-outline-variant/20 flex flex-col gap-2">
        <div className="text-[11px] font-semibold uppercase tracking-wider text-on-surface-variant/70 mb-1">
          Account & Authentication
        </div>
        <button
          onClick={() => handleNavClick('login')}
          className="flex items-center gap-3 py-2 px-3 rounded-xl text-label-md text-on-surface-variant hover:text-primary hover:bg-surface-container-high transition-colors"
        >
          <span className="material-symbols-outlined text-[18px]">login</span>
          <span>Switch / Log In</span>
        </button>
        <button
          onClick={() => handleNavClick('register')}
          className="flex items-center gap-3 py-2 px-3 rounded-xl text-label-md text-on-surface-variant hover:text-primary hover:bg-surface-container-high transition-colors"
        >
          <span className="material-symbols-outlined text-[18px]">person_add</span>
          <span>Create Account</span>
        </button>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Persistent Sidebar */}
      <aside className="w-sidebar-width h-full fixed left-0 top-0 hidden md:flex flex-col bg-surface-container-low border-r border-outline-variant/20 z-50 overflow-y-auto">
        {navContent}
      </aside>

      {/* Mobile Drawer Overlay */}
      {isOpenMobile && (
        <div className="fixed inset-0 z-50 md:hidden flex">
          <div
            className="fixed inset-0 bg-black/40 backdrop-blur-xs transition-opacity"
            onClick={onCloseMobile}
          />
          <aside className="relative w-sidebar-width max-w-[85vw] h-full bg-surface-container-low border-r border-outline-variant/20 shadow-2xl flex flex-col z-10 overflow-y-auto">
            <div className="flex justify-between items-center p-4 border-b border-outline-variant/20">
              <span className="text-headline-md font-bold text-primary">ScholarFlow</span>
              <button
                onClick={onCloseMobile}
                className="p-2 rounded-full text-on-surface-variant hover:bg-surface-container-high"
              >
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>
            {navContent}
          </aside>
        </div>
      )}
    </>
  );
};
