import React, { useState } from 'react';
import { Deadline } from '../types';

interface NewDeadlineModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddDeadline: (deadline: Deadline) => void;
}

export const NewDeadlineModal: React.FC<NewDeadlineModalProps> = ({
  isOpen,
  onClose,
  onAddDeadline,
}) => {
  const [title, setTitle] = useState('');
  const [subtitle, setSubtitle] = useState('');
  const [month, setMonth] = useState('Nov');
  const [day, setDay] = useState('15');
  const [type, setType] = useState<'urgent' | 'normal' | 'info'>('normal');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    const newDl: Deadline = {
      id: 'dl-' + Date.now(),
      title: title.trim(),
      subtitle: subtitle.trim() || 'Scheduled Academic Milestone',
      month: month.trim().substring(0, 3).toUpperCase(),
      day: day.trim(),
      type,
    };

    onAddDeadline(newDl);
    setTitle('');
    setSubtitle('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs animate-in fade-in">
      <div className="fixed inset-0" onClick={onClose} />
      <div className="relative w-full max-w-md bg-surface rounded-2xl custom-shadow border border-outline-variant/30 overflow-hidden z-10 p-6 md:p-8">
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary-container text-on-primary-container flex items-center justify-center">
              <span className="material-symbols-outlined text-2xl">event_upcoming</span>
            </div>
            <div>
              <h2 className="text-headline-md font-bold text-on-surface">Add Deadline</h2>
              <p className="text-label-sm text-on-surface-variant">Important date or exam</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-on-surface-variant hover:bg-surface-container-high transition-colors"
          >
            <span className="material-symbols-outlined">close</span>
          </button>
        </div>

        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <div>
            <label className="block text-label-md font-medium text-on-surface mb-1">
              Title / Event *
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Final Presentation"
              className="w-full h-11 px-4 bg-surface-container-lowest border border-outline-variant rounded-xl text-body-md text-on-surface focus:outline-none focus:border-primary"
            />
          </div>

          <div>
            <label className="block text-label-md font-medium text-on-surface mb-1">
              Subtitle / Details
            </label>
            <input
              type="text"
              value={subtitle}
              onChange={(e) => setSubtitle(e.target.value)}
              placeholder="e.g. Worth 15% of final grade"
              className="w-full h-11 px-4 bg-surface-container-lowest border border-outline-variant rounded-xl text-body-md text-on-surface focus:outline-none focus:border-primary"
            />
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-label-md font-medium text-on-surface mb-1">
                Month
              </label>
              <select
                value={month}
                onChange={(e) => setMonth(e.target.value)}
                className="w-full h-11 px-2 bg-surface-container-lowest border border-outline-variant rounded-xl text-body-md text-on-surface focus:outline-none focus:border-primary"
              >
                <option value="Oct">OCT</option>
                <option value="Nov">NOV</option>
                <option value="Dec">DEC</option>
                <option value="Jan">JAN</option>
              </select>
            </div>

            <div>
              <label className="block text-label-md font-medium text-on-surface mb-1">Day</label>
              <input
                type="number"
                min="1"
                max="31"
                value={day}
                onChange={(e) => setDay(e.target.value)}
                className="w-full h-11 px-3 bg-surface-container-lowest border border-outline-variant rounded-xl text-body-md text-on-surface focus:outline-none focus:border-primary"
              />
            </div>

            <div>
              <label className="block text-label-md font-medium text-on-surface mb-1">
                Category
              </label>
              <select
                value={type}
                onChange={(e) => setType(e.target.value as 'urgent' | 'normal' | 'info')}
                className="w-full h-11 px-2 bg-surface-container-lowest border border-outline-variant rounded-xl text-body-md text-on-surface focus:outline-none focus:border-primary"
              >
                <option value="urgent">Urgent</option>
                <option value="normal">Normal</option>
                <option value="info">Info</option>
              </select>
            </div>
          </div>

          <div className="flex gap-3 mt-4 pt-4 border-t border-outline-variant/20">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 h-11 border border-outline-variant rounded-full text-label-md font-medium text-on-surface hover:bg-surface-container-low transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 h-11 bg-primary text-on-primary rounded-full text-label-md font-medium hover:bg-primary/90 transition-colors shadow-sm flex items-center justify-center gap-2"
            >
              <span className="material-symbols-outlined text-[18px]">add</span>
              <span>Save Deadline</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
