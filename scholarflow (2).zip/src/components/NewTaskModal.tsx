import React, { useState } from 'react';
import { Assignment, PriorityType } from '../types';

interface NewTaskModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddTask: (task: Assignment) => void;
}

export const NewTaskModal: React.FC<NewTaskModalProps> = ({ isOpen, onClose, onAddTask }) => {
  const [title, setTitle] = useState('');
  const [course, setCourse] = useState('');
  const [priority, setPriority] = useState<PriorityType>('medium');
  const [dueDateText, setDueDateText] = useState('Due Next Week');
  const [progress, setProgress] = useState(0);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !course.trim()) return;

    const newTask: Assignment = {
      id: 'asgn-' + Date.now(),
      title: title.trim(),
      course: course.trim(),
      priority,
      status: progress === 100 ? 'Done' : progress > 0 ? 'In Progress' : 'Pending',
      dueDateText,
      dueIcon: priority === 'high' ? 'timer' : 'event',
      progress,
    };

    onAddTask(newTask);
    setTitle('');
    setCourse('');
    setProgress(0);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs animate-in fade-in">
      <div className="fixed inset-0" onClick={onClose} />
      <div className="relative w-full max-w-lg bg-surface rounded-2xl custom-shadow border border-outline-variant/30 overflow-hidden z-10 p-6 md:p-8">
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary-container text-on-primary-container flex items-center justify-center">
              <span className="material-symbols-outlined text-2xl">add_task</span>
            </div>
            <div>
              <h2 className="text-headline-md font-bold text-on-surface">New Task</h2>
              <p className="text-label-sm text-on-surface-variant">Add assignment to your list</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-on-surface-variant hover:bg-surface-container-high transition-colors"
          >
            <span className="material-symbols-outlined">close</span>
          </button>
        </div>

        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <div>
            <label className="block text-label-md font-medium text-on-surface mb-1">
              Task Title *
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Research Proposal"
              className="w-full h-11 px-4 bg-surface-container-lowest border border-outline-variant rounded-xl text-body-md text-on-surface focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary"
            />
          </div>

          <div>
            <label className="block text-label-md font-medium text-on-surface mb-1">
              Course / Subject *
            </label>
            <input
              type="text"
              required
              value={course}
              onChange={(e) => setCourse(e.target.value)}
              placeholder="e.g. Computer Science 302"
              className="w-full h-11 px-4 bg-surface-container-lowest border border-outline-variant rounded-xl text-body-md text-on-surface focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-label-md font-medium text-on-surface mb-1">
                Priority
              </label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value as PriorityType)}
                className="w-full h-11 px-3 bg-surface-container-lowest border border-outline-variant rounded-xl text-body-md text-on-surface focus:outline-none focus:border-primary"
              >
                <option value="high">High Priority</option>
                <option value="medium">Medium Priority</option>
                <option value="low">Low Priority</option>
              </select>
            </div>

            <div>
              <label className="block text-label-md font-medium text-on-surface mb-1">
                Due Date / Note
              </label>
              <input
                type="text"
                value={dueDateText}
                onChange={(e) => setDueDateText(e.target.value)}
                placeholder="e.g. Due Tomorrow"
                className="w-full h-11 px-4 bg-surface-container-lowest border border-outline-variant rounded-xl text-body-md text-on-surface focus:outline-none focus:border-primary"
              />
            </div>
          </div>

          <div>
            <div className="flex justify-between items-center mb-1">
              <label className="block text-label-md font-medium text-on-surface">
                Initial Progress
              </label>
              <span className="text-label-sm font-bold text-primary">{progress}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              step="5"
              value={progress}
              onChange={(e) => setProgress(Number(e.target.value))}
              className="w-full accent-primary cursor-pointer"
            />
          </div>

          <div className="flex gap-3 mt-4 pt-4 border-t border-outline-variant/20">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 h-11 border border-outline-variant rounded-full text-label-md font-medium text-on-surface hover:bg-surface-container-low transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 h-11 bg-primary text-on-primary rounded-full text-label-md font-medium hover:bg-primary/90 transition-colors shadow-sm flex items-center justify-center gap-2"
            >
              <span className="material-symbols-outlined text-[18px]">add</span>
              <span>Create Task</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
