import React, { useState } from 'react';
import { Assignment, Subject, ClassSession, Deadline, ViewType } from '../types';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  assignments: Assignment[];
  subjects: Subject[];
  todayClasses: ClassSession[];
  deadlines: Deadline[];
  onNavigate: (view: ViewType) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  assignments,
  subjects,
  todayClasses,
  deadlines,
  onNavigate,
}) => {
  const [query, setQuery] = useState('');

  if (!isOpen) return null;

  const q = query.trim().toLowerCase();

  const filteredAssignments = q
    ? assignments.filter(
        (a) => a.title.toLowerCase().includes(q) || a.course.toLowerCase().includes(q)
      )
    : assignments.slice(0, 3);

  const filteredSubjects = q
    ? subjects.filter(
        (s) =>
          s.title.toLowerCase().includes(q) ||
          s.code.toLowerCase().includes(q) ||
          s.professor.toLowerCase().includes(q)
      )
    : subjects.slice(0, 2);

  const filteredClasses = q
    ? todayClasses.filter(
        (c) =>
          c.title.toLowerCase().includes(q) ||
          c.instructor.toLowerCase().includes(q) ||
          c.location.toLowerCase().includes(q)
      )
    : todayClasses;

  const filteredDeadlines = q
    ? deadlines.filter(
        (d) => d.title.toLowerCase().includes(q) || d.subtitle.toLowerCase().includes(q)
      )
    : deadlines.slice(0, 2);

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-16 px-4 bg-black/40 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className="fixed inset-0"
        onClick={onClose}
      />
      <div className="relative w-full max-w-2xl bg-surface rounded-2xl custom-shadow border border-outline-variant/30 overflow-hidden z-10 flex flex-col max-h-[80vh]">
        {/* Search Bar Input */}
        <div className="flex items-center px-4 py-3 border-b border-outline-variant/30 bg-surface-container-low">
          <span className="material-symbols-outlined text-on-surface-variant mr-3 text-2xl">
            search
          </span>
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search assignments, subjects, classes, deadlines..."
            className="w-full bg-transparent border-none outline-none text-body-md font-body-md text-on-surface placeholder:text-on-surface-variant/50 focus:ring-0"
            autoFocus
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="p-1 rounded-full text-on-surface-variant hover:bg-surface-container-high text-xs mr-2"
            >
              Clear
            </button>
          )}
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-on-surface-variant hover:bg-surface-container-high transition-colors"
          >
            <span className="material-symbols-outlined">close</span>
          </button>
        </div>

        {/* Results Container */}
        <div className="p-4 overflow-y-auto flex flex-col gap-6 divide-y divide-outline-variant/10">
          {/* Assignments */}
          {filteredAssignments.length > 0 && (
            <div>
              <div className="flex justify-between items-center mb-2 px-1">
                <span className="text-label-sm font-bold text-primary uppercase tracking-wider">
                  Assignments ({filteredAssignments.length})
                </span>
                <button
                  onClick={() => {
                    onNavigate('assignments');
                    onClose();
                  }}
                  className="text-label-sm text-primary hover:underline font-semibold"
                >
                  View All
                </button>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {filteredAssignments.map((a) => (
                  <div
                    key={a.id}
                    onClick={() => {
                      onNavigate('assignments');
                      onClose();
                    }}
                    className="p-3 bg-surface-container-lowest rounded-xl border border-outline-variant/20 hover:border-primary/30 transition-all cursor-pointer"
                  >
                    <div className="flex justify-between items-start">
                      <span className="font-semibold text-primary text-body-md truncate">
                        {a.title}
                      </span>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-primary-fixed text-on-primary-fixed font-bold">
                        {a.priority}
                      </span>
                    </div>
                    <p className="text-label-sm text-secondary truncate mt-1">{a.course}</p>
                    <div className="mt-2 flex justify-between text-[11px] text-on-surface-variant">
                      <span>{a.status}</span>
                      <span>{a.dueDateText}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Subjects */}
          {filteredSubjects.length > 0 && (
            <div className="pt-4">
              <div className="flex justify-between items-center mb-2 px-1">
                <span className="text-label-sm font-bold text-primary uppercase tracking-wider">
                  Subjects ({filteredSubjects.length})
                </span>
                <button
                  onClick={() => {
                    onNavigate('subjects');
                    onClose();
                  }}
                  className="text-label-sm text-primary hover:underline font-semibold"
                >
                  View All
                </button>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {filteredSubjects.map((s) => (
                  <div
                    key={s.id}
                    onClick={() => {
                      onNavigate('subjects');
                      onClose();
                    }}
                    className="p-3 bg-surface-container-lowest rounded-xl border border-outline-variant/20 hover:border-primary/30 transition-all cursor-pointer"
                  >
                    <div className="flex justify-between">
                      <span className="text-xs font-bold text-on-surface-variant bg-surface-variant px-2 py-0.5 rounded">
                        {s.code}
                      </span>
                      <span className="text-xs font-bold text-primary">{s.attendance}% Att.</span>
                    </div>
                    <h4 className="font-bold text-on-surface mt-2 text-body-md">{s.title}</h4>
                    <p className="text-label-sm text-secondary mt-1">{s.professor}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Today's Classes */}
          {filteredClasses.length > 0 && (
            <div className="pt-4">
              <div className="flex justify-between items-center mb-2 px-1">
                <span className="text-label-sm font-bold text-primary uppercase tracking-wider">
                  Schedule / Classes
                </span>
                <button
                  onClick={() => {
                    onNavigate('timetable');
                    onClose();
                  }}
                  className="text-label-sm text-primary hover:underline font-semibold"
                >
                  Timetable
                </button>
              </div>
              <div className="flex flex-col gap-2">
                {filteredClasses.map((c) => (
                  <div
                    key={c.id}
                    onClick={() => {
                      onNavigate('timetable');
                      onClose();
                    }}
                    className="p-3 bg-surface-container-low rounded-xl border border-surface-variant flex justify-between items-center cursor-pointer hover:border-primary/30"
                  >
                    <div>
                      <span className="font-bold text-on-surface text-body-md">{c.title}</span>
                      <p className="text-label-sm text-on-surface-variant">
                        {c.location} • {c.instructor}
                      </p>
                    </div>
                    <span className="text-xs font-bold text-primary bg-primary-fixed/40 px-2.5 py-1 rounded-full">
                      {c.timeStart} - {c.timeEnd}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Deadlines */}
          {filteredDeadlines.length > 0 && (
            <div className="pt-4">
              <div className="flex justify-between items-center mb-2 px-1">
                <span className="text-label-sm font-bold text-primary uppercase tracking-wider">
                  Deadlines
                </span>
              </div>
              <div className="flex flex-col gap-2">
                {filteredDeadlines.map((d) => (
                  <div
                    key={d.id}
                    onClick={() => {
                      onNavigate('dashboard');
                      onClose();
                    }}
                    className="p-3 bg-surface-container-lowest rounded-xl border border-outline-variant/20 flex items-center gap-3 cursor-pointer hover:border-primary/30"
                  >
                    <div className="bg-error-container text-on-error-container p-2 rounded-lg text-center min-w-[45px]">
                      <span className="text-[10px] font-bold uppercase block">{d.month}</span>
                      <span className="text-body-lg font-bold leading-none">{d.day}</span>
                    </div>
                    <div>
                      <h5 className="font-bold text-on-surface text-body-md">{d.title}</h5>
                      <p className="text-label-sm text-on-surface-variant">{d.subtitle}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {q &&
            filteredAssignments.length === 0 &&
            filteredSubjects.length === 0 &&
            filteredClasses.length === 0 &&
            filteredDeadlines.length === 0 && (
              <div className="py-12 text-center text-on-surface-variant">
                <span className="material-symbols-outlined text-4xl text-outline mb-2">
                  search_off
                </span>
                <p className="text-body-md font-medium">No results found for "{query}"</p>
                <p className="text-label-sm text-outline mt-1">
                  Try searching for course names, titles, or professor names.
                </p>
              </div>
            )}
        </div>
      </div>
    </div>
  );
};
