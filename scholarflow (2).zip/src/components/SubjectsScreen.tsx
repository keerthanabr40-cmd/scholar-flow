import React, { useState } from 'react';
import { Subject } from '../types';

interface SubjectsScreenProps {
  subjects: Subject[];
  onOpenEnrollModal: () => void;
  onDeleteSubject: (id: string) => void;
  onUpdateAttendance: (id: string, newAttendance: number) => void;
}

export const SubjectsScreen: React.FC<SubjectsScreenProps> = ({
  subjects,
  onOpenEnrollModal,
  onDeleteSubject,
  onUpdateAttendance,
}) => {
  const [selectedSemester, setSelectedSemester] = useState('Semester 1');
  const [activeSubjectMenu, setActiveSubjectMenu] = useState<string | null>(null);

  return (
    <main className="flex-1 p-4 md:p-margin-desktop max-w-container-max mx-auto w-full flex flex-col gap-6 md:gap-gutter">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-surface-variant pb-6">
        <div>
          <h1 className="text-3xl md:text-headline-lg font-bold text-on-surface tracking-tight">
            Current Subjects
          </h1>
          <p className="text-body-md text-on-surface-variant mt-1">
            {selectedSemester} • Academic Year 2024-2025
          </p>
        </div>

        <div className="flex items-center gap-3">
          <select
            value={selectedSemester}
            onChange={(e) => setSelectedSemester(e.target.value)}
            className="px-4 py-3 bg-surface-container-low border border-outline-variant/30 rounded-full text-body-md font-bold text-on-surface focus:outline-none cursor-pointer"
          >
            <option value="Semester 1">Semester 1</option>
            <option value="Semester 2">Semester 2</option>
            <option value="Summer Term">Summer Term</option>
          </select>

          <button
            onClick={onOpenEnrollModal}
            className="bg-primary text-on-primary hover:bg-primary/90 font-bold px-6 py-3 rounded-full flex items-center gap-2 shadow-sm active:scale-95 transition-all cursor-pointer"
          >
            <span className="material-symbols-outlined text-[20px]">add</span>
            <span>Enroll Subject</span>
          </button>
        </div>
      </div>

      {/* Grid of Course Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-gutter">
        {subjects.map((subj) => (
          <div
            key={subj.id}
            className="bg-surface rounded-2xl p-6 card-shadow border border-surface-container-high flex flex-col justify-between relative hover:border-primary/30 transition-all group"
          >
            <div>
              {/* Card Header */}
              <div className="flex justify-between items-start gap-2 mb-3">
                <div className="flex items-center gap-2">
                  <span className="text-label-md font-bold text-primary bg-primary-fixed/40 px-3 py-1 rounded-md tracking-wider">
                    {subj.code}
                  </span>
                  <span className="text-label-sm font-semibold text-on-surface-variant bg-surface-variant px-2.5 py-1 rounded-md">
                    {subj.credits} Credits
                  </span>
                </div>

                {/* 3-Dots Action Menu */}
                <div className="relative">
                  <button
                    onClick={() =>
                      setActiveSubjectMenu(activeSubjectMenu === subj.id ? null : subj.id)
                    }
                    className="p-1.5 rounded-full text-on-surface-variant hover:bg-surface-container-high transition-colors cursor-pointer"
                    title="Course Actions"
                  >
                    <span className="material-symbols-outlined">more_vert</span>
                  </button>

                  {activeSubjectMenu === subj.id && (
                    <div className="absolute right-0 top-8 w-48 bg-surface rounded-xl custom-shadow border border-outline-variant/30 py-2 z-20">
                      <button
                        onClick={() => {
                          const newAtt = prompt('Enter new attendance %', String(subj.attendance));
                          if (newAtt !== null) {
                            onUpdateAttendance(subj.id, Number(newAtt) || 0);
                          }
                          setActiveSubjectMenu(null);
                        }}
                        className="w-full text-left px-4 py-2 text-label-md text-on-surface hover:bg-surface-container-low flex items-center gap-2"
                      >
                        <span className="material-symbols-outlined text-sm">edit</span>
                        <span>Update Attendance</span>
                      </button>
                      <button
                        onClick={() => {
                          if (confirm(`Unenroll from ${subj.code}?`)) {
                            onDeleteSubject(subj.id);
                          }
                          setActiveSubjectMenu(null);
                        }}
                        className="w-full text-left px-4 py-2 text-label-md text-error hover:bg-error-container/20 flex items-center gap-2"
                      >
                        <span className="material-symbols-outlined text-sm">delete</span>
                        <span>Drop Course</span>
                      </button>
                    </div>
                  )}
                </div>
              </div>

              {/* Course Title & Description */}
              <h2 className="text-headline-md font-bold text-on-surface mb-2">{subj.title}</h2>
              <p className="text-body-md text-on-surface-variant mb-6 line-clamp-2">
                {subj.description}
              </p>

              {/* Course Metadata Grid */}
              <div className="grid grid-cols-2 gap-3 mb-6 bg-surface-container-low p-4 rounded-xl border border-surface-variant text-label-md">
                <div className="flex items-center gap-2 text-on-surface-variant truncate">
                  <span className="material-symbols-outlined text-primary text-[18px]">person</span>
                  <span className="truncate">{subj.professor}</span>
                </div>
                <div className="flex items-center gap-2 text-on-surface-variant truncate">
                  <span className="material-symbols-outlined text-primary text-[18px]">meeting_room</span>
                  <span className="truncate">{subj.room}</span>
                </div>
                <div className="flex items-center gap-2 text-on-surface-variant truncate">
                  <span className="material-symbols-outlined text-primary text-[18px]">schedule</span>
                  <span className="truncate">{subj.schedule}</span>
                </div>
                <div className="flex items-center gap-2 text-on-surface-variant truncate">
                  <span className="material-symbols-outlined text-primary text-[18px]">school</span>
                  <span className="truncate">{subj.credits} Credits</span>
                </div>
              </div>
            </div>

            {/* Attendance Bar Footer */}
            <div className="pt-2 border-t border-surface-variant">
              <div className="flex justify-between items-center text-label-sm font-bold mb-1.5">
                <span className="text-on-surface-variant">Attendance Rate</span>
                <span
                  className={
                    subj.attendance >= 85
                      ? 'text-primary'
                      : subj.attendance >= 75
                      ? 'text-secondary'
                      : 'text-error'
                  }
                >
                  {subj.attendance}%
                </span>
              </div>
              <div className="w-full bg-surface-variant h-2.5 rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all duration-500 ${
                    subj.attendance >= 85
                      ? 'bg-primary'
                      : subj.attendance >= 75
                      ? 'bg-secondary'
                      : 'bg-error'
                  }`}
                  style={{ width: `${subj.attendance}%` }}
                />
              </div>
            </div>
          </div>
        ))}
      </div>
    </main>
  );
};
