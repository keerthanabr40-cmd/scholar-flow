import React, { useState } from 'react';
import { TimetableBlock } from '../types';

interface TimetableScreenProps {
  blocks: TimetableBlock[];
  onAddBlock: (block: TimetableBlock) => void;
  onDeleteBlock: (id: string) => void;
}

export const TimetableScreen: React.FC<TimetableScreenProps> = ({
  blocks,
  onAddBlock,
  onDeleteBlock,
}) => {
  const days = [
    { label: 'Aug 9', title: 'TODAY' },
    { label: 'Aug 10', title: 'Saturday' },
    { label: 'Aug 11', title: 'Sunday' },
    { label: 'Aug 12', title: 'Monday' },
    { label: 'Aug 13', title: 'Tuesday' },
  ];

  const [activeDay, setActiveDay] = useState<'Aug 9' | 'Aug 10' | 'Aug 11' | 'Aug 12' | 'Aug 13'>(
    'Aug 9'
  );

  const activeDayBlocks = blocks.filter((b) => b.day === activeDay);

  const handleQuickAdd = () => {
    const title = prompt('Enter Course Name (e.g. Artificial Intelligence)');
    if (!title) return;
    const code = prompt('Enter Course Code (e.g. CS420)') || 'CS420';
    const startTime = prompt('Start Time (e.g. 2:00 PM)') || '2:00 PM';
    const endTime = prompt('End Time (e.g. 3:30 PM)') || '3:30 PM';
    const location = prompt('Location/Room (e.g. Hall C)') || 'Hall C';
    const instructor = prompt('Instructor (e.g. Prof. Smith)') || 'Prof. Smith';

    const newBlock: TimetableBlock = {
      id: 'tt-' + Date.now(),
      code,
      title,
      day: activeDay,
      dayLabel: days.find((d) => d.label === activeDay)?.title as any,
      startTime,
      endTime,
      location,
      instructor,
    };

    onAddBlock(newBlock);
  };

  return (
    <main className="flex-1 p-4 md:p-margin-desktop max-w-container-max mx-auto w-full flex flex-col gap-6 md:gap-gutter">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-surface-variant pb-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-label-sm font-bold text-primary bg-primary-fixed/40 px-3 py-0.5 rounded-full uppercase tracking-wider">
              Week 8
            </span>
            <span className="text-label-md text-on-surface-variant font-medium">
              Aug 9 - Aug 13, 2026
            </span>
          </div>
          <h1 className="text-3xl md:text-headline-lg font-bold text-on-surface tracking-tight">
            Live Class Schedule
          </h1>
        </div>

        <button
          onClick={handleQuickAdd}
          className="bg-primary text-on-primary hover:bg-primary/90 font-bold px-6 py-3 rounded-full flex items-center gap-2 shadow-sm active:scale-95 transition-all cursor-pointer"
        >
          <span className="material-symbols-outlined text-[20px]">add</span>
          <span>Add Class</span>
        </button>
      </div>

      {/* Day Selector Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-none">
        {days.map((d) => {
          const isActive = activeDay === d.label;
          return (
            <button
              key={d.label}
              onClick={() => setActiveDay(d.label as any)}
              className={`px-5 py-3 rounded-2xl flex flex-col items-center min-w-[120px] transition-all cursor-pointer border ${
                isActive
                  ? 'bg-primary text-on-primary border-primary shadow-md font-bold scale-[1.02]'
                  : 'bg-surface text-on-surface border-surface-container-high hover:bg-surface-container-low'
              }`}
            >
              <span className="text-label-sm uppercase font-bold opacity-80">{d.title}</span>
              <span className="text-headline-sm font-bold mt-0.5">{d.label}</span>
            </button>
          );
        })}
      </div>

      {/* Timetable Schedule Cards View */}
      <div className="bg-surface rounded-2xl p-6 card-shadow border border-surface-container-high flex flex-col gap-6">
        <div className="flex justify-between items-center border-b border-surface-variant pb-4">
          <h2 className="text-headline-md font-bold text-on-surface">
            Schedule for {activeDay}
          </h2>
          <span className="text-label-md text-on-surface-variant font-medium">
            {activeDayBlocks.length} Scheduled Sessions
          </span>
        </div>

        {activeDayBlocks.length > 0 ? (
          <div className="space-y-4">
            {activeDayBlocks.map((block, idx) => (
              <React.Fragment key={block.id}>
                <div className="flex flex-col md:flex-row md:items-center justify-between p-5 bg-surface-container-low rounded-2xl border border-surface-variant hover:border-primary/30 transition-all gap-4 group">
                  <div className="flex items-start md:items-center gap-4">
                    <div className="p-3 bg-primary-container text-on-primary-container rounded-xl font-bold text-headline-sm shrink-0 min-w-[70px] text-center">
                      {block.code}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="text-headline-sm font-bold text-on-surface">
                          {block.title}
                        </h3>
                        {activeDay === 'Aug 9' && idx === 0 && (
                          <span className="text-[10px] font-bold bg-error-container text-on-error-container px-2 py-0.5 rounded-full uppercase tracking-wide animate-pulse">
                            Live Now
                          </span>
                        )}
                      </div>
                      <div className="flex flex-wrap items-center gap-4 mt-1 text-label-md text-on-surface-variant">
                        <span className="flex items-center gap-1">
                          <span className="material-symbols-outlined text-[18px] text-primary">
                            person
                          </span>
                          {block.instructor}
                        </span>
                        <span className="flex items-center gap-1">
                          <span className="material-symbols-outlined text-[18px] text-primary">
                            location_on
                          </span>
                          {block.location}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between md:justify-end gap-4 border-t md:border-t-0 pt-3 md:pt-0 border-surface-variant">
                    <span className="text-label-md font-bold text-primary bg-primary-fixed/40 px-4 py-2 rounded-full">
                      {block.startTime} - {block.endTime}
                    </span>
                    <button
                      onClick={() => onDeleteBlock(block.id)}
                      className="p-2 text-on-surface-variant hover:text-error rounded-full hover:bg-surface-container-high transition-colors cursor-pointer"
                      title="Remove Session"
                    >
                      <span className="material-symbols-outlined text-[20px]">delete</span>
                    </button>
                  </div>
                </div>

                {/* Lunch Break Insert at ~12:30 PM */}
                {idx === 0 && (
                  <div className="my-2 p-3 rounded-xl border border-dashed border-outline-variant/40 bg-surface-container-lowest/50 flex items-center justify-center gap-2 text-label-md text-on-surface-variant/80">
                    <span className="material-symbols-outlined text-[20px]">restaurant</span>
                    <span>12:30 PM - 01:30 PM • Lunch Break & Social Hour</span>
                  </div>
                )}
              </React.Fragment>
            ))}
          </div>
        ) : (
          <div className="py-16 text-center text-on-surface-variant">
            <span className="material-symbols-outlined text-5xl text-outline mb-2">
              event_available
            </span>
            <h3 className="text-headline-md font-bold text-on-surface">No classes scheduled</h3>
            <p className="text-body-md text-on-surface-variant mt-1">
              Enjoy your study break or add a new class session above.
            </p>
          </div>
        )}
      </div>
    </main>
  );
};
