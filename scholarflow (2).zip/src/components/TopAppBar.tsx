import React from 'react';
import { StudentProfile } from '../types';

interface TopAppBarProps {
  profile: StudentProfile;
  onOpenMobileMenu: () => void;
  onOpenSearch: () => void;
  onNavigateProfile?: () => void;
}

export const TopAppBar: React.FC<TopAppBarProps> = ({
  profile,
  onOpenMobileMenu,
  onOpenSearch,
  onNavigateProfile,
}) => {
  return (
    <header className="w-full top-0 sticky bg-surface shadow-[0px_4px_20px_rgba(114,47,55,0.05)] z-40 border-b border-outline-variant/10">
      <div className="flex justify-between items-center px-4 md:px-margin-desktop h-16 w-full max-w-container-max mx-auto">
        <div className="flex items-center gap-3">
          <button
            onClick={onOpenMobileMenu}
            className="md:hidden p-2 rounded-full text-on-surface-variant hover:bg-surface-container-low transition-colors"
            title="Open Menu"
          >
            <span className="material-symbols-outlined">menu</span>
          </button>
          <span className="text-headline-md font-bold text-primary tracking-tight cursor-pointer">
            ScholarFlow
          </span>
        </div>

        <div className="flex items-center gap-3 md:gap-6">
          <button
            onClick={onOpenSearch}
            className="w-10 h-10 rounded-full flex items-center justify-center text-on-surface-variant hover:bg-surface-container-low transition-colors cursor-pointer active:scale-95"
            title="Search assignments, subjects, schedule..."
          >
            <span className="material-symbols-outlined">search</span>
          </button>

          <button
            onClick={onNavigateProfile}
            className="flex items-center gap-2 p-1 rounded-full hover:bg-surface-container-low transition-colors group"
            title="View Profile"
          >
            <img
              src={profile.avatarUrl}
              alt={profile.name}
              className="w-8 h-8 rounded-full object-cover border border-outline-variant/40 group-hover:border-primary transition-colors"
              onError={(e) => {
                (e.currentTarget as HTMLImageElement).src =
                  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=400&auto=format&fit=crop';
              }}
            />
          </button>
        </div>
      </div>
    </header>
  );
};
