export type ViewType =
  | 'dashboard'
  | 'timetable'
  | 'assignments'
  | 'analytics'
  | 'subjects'
  | 'calendar'
  | 'login'
  | 'register'
  | 'forgot-password';

export interface StudentProfile {
  name: string;
  role: string;
  tier: string;
  email: string;
  studentId: string;
  avatarUrl: string;
}

export type PriorityType = 'high' | 'medium' | 'low';
export type AssignmentStatus = 'In Progress' | 'Pending' | 'Done';

export interface Assignment {
  id: string;
  title: string;
  course: string;
  priority: PriorityType;
  status: AssignmentStatus;
  dueDateText: string;
  dueIcon: 'timer' | 'event';
  dueDateIso?: string;
  progress: number;
}

export interface Subject {
  id: string;
  code: string;
  title: string;
  description: string;
  professor: string;
  room: string;
  schedule: string;
  credits: number;
  attendance: number;
}

export interface ClassSession {
  id: string;
  timeStart: string;
  timeEnd: string;
  title: string;
  location: string;
  instructor: string;
  isCurrent?: boolean;
}

export interface Deadline {
  id: string;
  title: string;
  subtitle: string;
  month: string;
  day: string;
  type: 'urgent' | 'normal' | 'info';
  dateIso?: string;
}

export interface TimetableBlock {
  id: string;
  code: string;
  title: string;
  day: 'Aug 9' | 'Aug 10' | 'Aug 11' | 'Aug 12' | 'Aug 13';
  dayLabel: 'TODAY' | 'Saturday' | 'Sunday' | 'Monday' | 'Tuesday';
  startTime: string;
  endTime: string;
  instructor: string;
  location: string;
}
